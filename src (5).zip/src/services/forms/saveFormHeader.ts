import { supabase } from "../../db/supabaseClient";
import { TABLES } from "../../constants/database";
import { z } from "zod";
import { formatZodErrors, ValidationError } from "../../utils/validation";

// Validation schema for form header data
const formHeaderSchema = z.object({
  id: z.string().uuid("Invalid form ID format"),
  form_number: z.string().nullable(),
  user_form_id: z.string().nullable(),
  title: z.string().nullable(),
  form_date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date format (YYYY-MM-DD)")
    .nullable(),
});

export interface SaveFormHeaderInput {
  formId: string;
  formNumber: string | null;
  userFormId: string | null;
  title: string | null;
  formDate: string | null;
}

export interface SaveFormHeaderResult {
  success: boolean;
  error?: {
    message: string;
    details?: string;
  };
  validationErrors?: ValidationError[];
}

export async function saveFormHeader({
  formId,
  formNumber,
  userFormId,
  title,
  formDate,
}: SaveFormHeaderInput): Promise<SaveFormHeaderResult> {
  try {
    // Validate input using Zod schema
    const validationResult = formHeaderSchema.safeParse({
      id: formId,
      form_number: formNumber,
      user_form_id: userFormId,
      title,
      form_date: formDate,
    });

    if (!validationResult.success) {
      return {
        success: false,
        error: { message: "Invalid form header data" },
        validationErrors: formatZodErrors(validationResult.error),
      };
    }

    // Upsert form header data
    const { error } = await supabase.from(TABLES.formInstances).upsert({
      id: formId,
      form_number: formNumber,
      user_form_id: userFormId,
      title,
      form_date: formDate,
    });

    if (error) {
      return {
        success: false,
        error: { message: error.message, details: error.details },
      };
    }

    return { success: true };
  } catch (error: any) {
    console.error("Save form header error:", error);
    return {
      success: false,
      error: {
        message: "Failed to save form header",
        details: error.message,
      },
    };
  }
}
