import { supabase } from "../../db/supabaseClient";
import { STORAGE_BUCKETS } from "../../constants/storage";

// Helper to get storage path for a signature
function getSignatureStoragePath(formId: string, signatureId: string) {
  return `signatures/${formId}/${signatureId}.png`;
}

interface GetSignatureUrlResult {
  success: boolean;
  url?: string;
  error?: Error;
}

export async function getSignatureUrl(
  formId: string,
  signatureId: string,
  expiresIn: number = 3600
): Promise<GetSignatureUrlResult> {
  try {
    const storagePath = getSignatureStoragePath(formId, signatureId);
    const { data, error } = await supabase.storage
      .from(STORAGE_BUCKETS.signatures)
      .createSignedUrl(storagePath, expiresIn);

    if (error) {
      throw error;
    }

    if (!data?.signedUrl) {
      throw new Error("No signed URL returned");
    }

    return {
      success: true,
      url: data.signedUrl,
    };
  } catch (error) {
    console.error("Error getting signature URL:", error);
    return {
      success: false,
      error:
        error instanceof Error ? error : new Error("Unknown error occurred"),
    };
  }
}
