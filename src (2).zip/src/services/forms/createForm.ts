import { supabase } from "../../db/supabaseClient";
import { TABLES, FORM_INSTANCE_FIELDS } from "../../constants/database";

export interface CreateFormInput {
  user_id?: string;
  status?: "draft" | "submitted" | "archived";
  company_id?: string;
  project_id?: string;
  title?: string;
  description?: string;
}

export interface FlraForm {
  id: string;
  user_id: string;
  company_id?: string;
  project_id?: string;
  title?: string;
  description?: string;
  status: "draft" | "submitted" | "archived";
  created_at: string;
  submitted_at?: string | null;
}

export interface SupabaseError {
  message: string;
  details?: string;
}

export async function createForm({
  user_id,
  status = "draft",
  company_id,
  project_id,
  title,
  description,
}: CreateFormInput): Promise<{
  form: FlraForm | null;
  error: SupabaseError | null;
}> {
  try {
    // Get authenticated user if user_id not provided
    if (!user_id) {
      console.log("Supabase Query:", {
        operation: "auth.getUser",
        fullQuery: { auth: { getUser: true } },
      });
      const { data: userData, error: userError } =
        await supabase.auth.getUser();
      if (userError || !userData?.user) {
        return {
          form: null,
          error: { message: "User not authenticated" },
        };
      }
      user_id = userData.user.id;
    }

    // Insert new form
    console.log("Supabase Query:", {
      table: TABLES.formInstances,
      operation: "insert",
      data: {
        [FORM_INSTANCE_FIELDS.userId]: user_id,
        [FORM_INSTANCE_FIELDS.companyId]: company_id,
        [FORM_INSTANCE_FIELDS.projectId]: project_id,
        [FORM_INSTANCE_FIELDS.title]: title,
        [FORM_INSTANCE_FIELDS.description]: description,
        [FORM_INSTANCE_FIELDS.status]: status,
        [FORM_INSTANCE_FIELDS.submittedAt]:
          status === "submitted" ? new Date().toISOString() : null,
      },
      fullQuery: {
        from: TABLES.formInstances,
        insert: [
          {
            [FORM_INSTANCE_FIELDS.userId]: user_id,
            [FORM_INSTANCE_FIELDS.companyId]: company_id,
            [FORM_INSTANCE_FIELDS.projectId]: project_id,
            [FORM_INSTANCE_FIELDS.title]: title,
            [FORM_INSTANCE_FIELDS.description]: description,
            [FORM_INSTANCE_FIELDS.status]: status,
            [FORM_INSTANCE_FIELDS.submittedAt]:
              status === "submitted" ? new Date().toISOString() : null,
          },
        ],
        select: true,
        single: true,
      },
    });
    const { data, error } = await supabase
      .from(TABLES.formInstances)
      .insert([
        {
          [FORM_INSTANCE_FIELDS.userId]: user_id,
          [FORM_INSTANCE_FIELDS.companyId]: company_id,
          [FORM_INSTANCE_FIELDS.projectId]: project_id,
          [FORM_INSTANCE_FIELDS.title]: title,
          [FORM_INSTANCE_FIELDS.description]: description,
          [FORM_INSTANCE_FIELDS.status]: status,
          [FORM_INSTANCE_FIELDS.submittedAt]:
            status === "submitted" ? new Date().toISOString() : null,
        },
      ])
      .select()
      .single();

    if (error) {
      return {
        form: null,
        error: { message: error.message, details: error.details },
      };
    }

    // Runtime guard for returned data
    if (!data || !data.id) {
      return {
        form: null,
        error: { message: "Invalid form response from Supabase" },
      };
    }

    return { form: data as FlraForm, error: null };
  } catch (error) {
    return {
      form: null,
      error: {
        message:
          error instanceof Error ? error.message : "Unknown error occurred",
        details: error instanceof Error ? error.stack : undefined,
      },
    };
  }
}
