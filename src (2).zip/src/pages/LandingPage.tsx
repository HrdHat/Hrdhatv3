import React from "react";

const LandingPage: React.FC = () => {
  return (
    <div>
      <h1>Welcome</h1>
      {/* Landing page content for non-authenticated users will go here */}
    </div>
  );
};

export default LandingPage;
