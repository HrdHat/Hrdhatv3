/**
 * FLRA Form Builder Component
 *
 * This is the main component for creating and editing FLRA (Field Level Risk Assessment) forms.
 * It manages the form state and coordinates between different form modules.
 *
 * Key Features:
 * - Generates and maintains stable form IDs for the session
 * - Creates database records for new forms
 * - Manages form state across multiple modules
 * - Handles photo uploads with proper form association
 * - Coordinates user signatures
 *
 * Form Modules:
 * - Header (form metadata)
 * - General Information
 * - Pre-Job Task Checklist
 * - PPE Equipment Checklist
 * - Task Hazard Control
 * - Photos
 * - Signatures
 */

import React, { useState, useEffect } from "react";
import FlraHeaderModule from "../../formmodules/FlraHeaderModule";
import GeneralInformationModule from "../../formmodules/GeneralInformationModule";
import PreJobTaskChecklistModule from "../../formmodules/PreJobTaskChecklistModule";
import PpeEquipmentChecklistModule from "../../formmodules/PpeEquipmentChecklistModule";
import TaskHazardControlModule from "../../formmodules/TaskHazardControlModule";
import FlraPhotosModule from "../../formmodules/FlraPhotosModule";
import SignaturesModule from "../../formmodules/SignaturesModule";
import { FlraFormState } from "../../../types/formTypes";
import { useAuth } from "../../../session/AuthProvider";
import { ensureFormRowExists } from "../../../services/forms/createOrUpdateForm";
import { moduleMap } from "./moduleMap";
import { createForm } from "../../../services/forms/createOrUpdateForm";

// TEMPORARY: Bridge solution until full form saving is implemented
// This function generates a stable form ID that will be used to organize photos
// during the current form creation session. It will be replaced by proper database IDs
// when the full form saving functionality is implemented.
const generateFormId = () => {
  return `flra_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

const initialState: FlraFormState = {
  header: {},
  general: {},
  preJobChecklist: {},
  ppeChecklist: {},
  taskHazards: [],
  photos: [],
  signatures: [],
  status: "draft",
  formId: generateFormId(),
  photosModuleId: `photos_${Date.now()}_${Math.random()
    .toString(36)
    .substr(2, 9)}`,
};

type ModuleKey = keyof typeof moduleMap;

const moduleOrder: ModuleKey[] = [
  "header",
  "general",
  "preJobChecklist",
  "ppeChecklist",
  "taskHazards",
  "photos",
  "signatures",
];

const FlraFormBuilder: React.FC = () => {
  const [formState, setFormState] = useState<FlraFormState>(initialState);
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Create form row when component mounts
  useEffect(() => {
    const initializeForm = async () => {
      if (user?.id && formState.formId) {
        try {
          await ensureFormRowExists(formState.formId, user.id);
        } catch (error) {
          console.error("Failed to initialize form:", error);
          // Handle error appropriately
        }
      }
    };
    initializeForm();
  }, [user?.id, formState.formId]);

  const handleModuleChange = async (moduleKey: ModuleKey, value: any) => {
    try {
      setFormState((prev) => ({ ...prev, [moduleKey]: value }));
      // Save module data to Supabase
      await saveFormModuleData(formState.formId, moduleKey, value);
    } catch (error) {
      console.error(`Failed to save ${moduleKey} module:`, error);
      // Handle error appropriately
    }
  };

  const handleSubmit = async () => {
    if (!user?.id) return;

    setIsSubmitting(true);
    try {
      // Update form status to submitted
      await createForm({
        id: formState.formId,
        user_id: user.id,
        status: "submitted",
        // Add any other required form data
      });

      // Reset form state for new form
      setFormState({
        ...initialState,
        formId: generateFormId(),
        photosModuleId: `photos_${Date.now()}_${Math.random()
          .toString(36)
          .substr(2, 9)}`,
      });
    } catch (error) {
      console.error("Failed to submit form:", error);
      // Handle error appropriately
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!formState.formId || !formState.photosModuleId) {
    throw new Error("FormBuilder missing stable ID. Something is wrong.");
  }

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Create New FLRA</h1>
        <button
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:bg-gray-400"
        >
          {isSubmitting ? "Submitting..." : "Submit FLRA"}
        </button>
      </div>

      {moduleOrder.map((key) => {
        const ModuleComponent = moduleMap[key];
        if (!ModuleComponent) return null;

        return (
          <div key={key} className="mb-8">
            <ModuleComponent
              value={formState[key]}
              onChange={(value: any) => handleModuleChange(key, value)}
              formId={formState.formId}
            />
          </div>
        );
      })}
    </div>
  );
};

export default FlraFormBuilder;
