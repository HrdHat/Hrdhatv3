/**
 * ImageUploaderBase Component
 *
 * A core component that handles image file selection and upload functionality.
 * Features:
 * - Batch file selection and upload
 * - Progress tracking per file
 * - Gallery view of uploaded images with titles
 * - Individual image removal with soft delete
 * - Click to view full image
 * - Upload limits and validation
 * - Photo count tracking
 *
 * This component is designed to be extended by platform-specific versions
 * (desktop with camera, mobile with native camera) while maintaining
 * consistent upload behavior.
 */

import React, { useState, useRef } from "react";
import {
  uploadImageToFormModule,
  FormPhoto,
} from "../../services/forms/uploadImageToFormModule";
import { supabase } from "../../db/supabaseClient";

export type ImageUploaderBaseProps = {
  formId: string;
  formModuleId: string;
  uploadedBy: string;
  tag?: string;
  maxPhotos?: number;
  onUploadSuccess?: (photo: FormPhoto) => void;
  onUploadError?: (error: Error) => void;
  // Allow custom file input props to be passed through
  fileInputProps?: React.InputHTMLAttributes<HTMLInputElement>;
};

type UploadStatus = {
  file: File;
  progress: number;
  error?: Error;
  photo?: FormPhoto;
};

export const ImageUploaderBase: React.FC<ImageUploaderBaseProps> = ({
  formId,
  formModuleId,
  uploadedBy,
  tag,
  maxPhotos = 10,
  onUploadSuccess,
  onUploadError,
  fileInputProps = {},
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatuses, setUploadStatuses] = useState<UploadStatus[]>([]);
  const [uploadedPhotos, setUploadedPhotos] = useState<FormPhoto[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    // Check if adding these files would exceed the limit
    if (uploadedPhotos.length + files.length > maxPhotos) {
      const error = new Error(`Maximum ${maxPhotos} photos allowed`);
      onUploadError?.(error);
      return;
    }

    setIsUploading(true);
    const newStatuses: UploadStatus[] = files.map((file) => ({
      file,
      progress: 0,
    }));
    setUploadStatuses((prev) => [...prev, ...newStatuses]);

    // Upload files sequentially to avoid overwhelming the server
    for (const status of newStatuses) {
      try {
        // Update progress
        setUploadStatuses((prev) =>
          prev.map((s) => (s.file === status.file ? { ...s, progress: 10 } : s))
        );

        const photo = await uploadImageToFormModule({
          formId,
          formModuleId,
          file: status.file,
          uploadedBy,
          tag,
          source: "web",
        });

        // Update status with success
        setUploadStatuses((prev) =>
          prev.map((s) =>
            s.file === status.file ? { ...s, progress: 100, photo } : s
          )
        );

        setUploadedPhotos((prev) => [...prev, photo]);
        onUploadSuccess?.(photo);
      } catch (error) {
        console.error("Upload failed:", error);
        // Update status with error
        setUploadStatuses((prev) =>
          prev.map((s) =>
            s.file === status.file ? { ...s, error: error as Error } : s
          )
        );
        onUploadError?.(error as Error);
      }
    }

    setIsUploading(false);
    // Clear the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handlePreviewClick = (photo: FormPhoto) => {
    if (photo.public_url) {
      window.open(photo.public_url, "_blank");
    }
  };

  const handleRemove = async (photoToRemove: FormPhoto) => {
    if (confirm("Remove this photo?")) {
      try {
        // Attempt soft delete in database
        const { error } = await supabase
          .from("form_data_photos")
          .update({
            is_deleted: true,
            deleted_at: new Date().toISOString(),
          })
          .eq("id", photoToRemove.id);

        if (error) throw error;

        // Update UI on successful soft delete
        setUploadedPhotos((prev) =>
          prev.filter((p) => p.id !== photoToRemove.id)
        );
      } catch (error) {
        console.error("Failed to soft delete photo:", error);
        // Fall back to UI-only removal if database update fails
        setUploadedPhotos((prev) =>
          prev.filter((p) => p.id !== photoToRemove.id)
        );
      }
    }
  };

  return (
    <div>
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/jpeg,image/png,image/heic,image/heif"
        onChange={handleFileSelect}
        style={{ display: "none" }}
        {...fileInputProps}
      />

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          marginBottom: 8,
        }}
      >
        <button
          onClick={handleClick}
          disabled={isUploading || uploadedPhotos.length >= maxPhotos}
        >
          {isUploading
            ? "Uploading..."
            : uploadedPhotos.length >= maxPhotos
            ? `Maximum ${maxPhotos} photos reached`
            : "Add Photos"}
        </button>
        <p style={{ margin: 0, color: "#666" }}>
          {uploadedPhotos.length} of {maxPhotos} photos uploaded
        </p>
      </div>

      {/* Upload Progress */}
      {uploadStatuses.length > 0 && (
        <div style={{ marginTop: 8 }}>
          {uploadStatuses.map((status, index) => (
            <div key={index} style={{ marginBottom: 4 }}>
              {status.file.name} - {status.progress}%
              {status.error && (
                <span style={{ color: "red" }}>
                  {" "}
                  - Failed: {status.error.message}
                </span>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Photo Gallery */}
      {uploadedPhotos.length > 0 && (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))",
            gap: 8,
            marginTop: 8,
          }}
        >
          {uploadedPhotos.map((photo) => (
            <div key={photo.id} style={{ position: "relative" }}>
              <img
                src={photo.public_url}
                alt={photo.description || "Uploaded image"}
                title={photo.file_name}
                onClick={() => handlePreviewClick(photo)}
                style={{
                  width: "100%",
                  height: 100,
                  objectFit: "cover",
                  cursor: "pointer",
                  borderRadius: 8,
                }}
              />
              <div
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 0,
                  right: 0,
                  padding: "4px",
                  background: "rgba(0, 0, 0, 0.5)",
                  color: "white",
                  fontSize: 12,
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                }}
              >
                {photo.file_name}
              </div>
              <button
                onClick={() => handleRemove(photo)}
                style={{
                  position: "absolute",
                  top: 4,
                  right: 4,
                  padding: "2px 6px",
                  fontSize: 12,
                  backgroundColor: "rgba(255, 255, 255, 0.8)",
                  border: "none",
                  borderRadius: 4,
                  cursor: "pointer",
                }}
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
