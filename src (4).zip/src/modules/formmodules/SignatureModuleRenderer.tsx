import React from "react";
import SignatureModule from "./SignatureModule";

const SignatureModuleRenderer = (props) => <SignatureModule {...props} />;

export default SignatureModuleRenderer;
