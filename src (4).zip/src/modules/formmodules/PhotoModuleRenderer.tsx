import React from "react";
import FormAssetPhotosModule from "./FormAssetPhotosModule";

const PhotoModuleRenderer = (props) => <FormAssetPhotosModule {...props} />;

export default PhotoModuleRenderer;
