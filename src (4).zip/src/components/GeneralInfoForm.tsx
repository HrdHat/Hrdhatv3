import React, { useState, useEffect } from "react";
import { GeneralInfo } from "../types/formSchemas";
import { supabase } from "../db/supabaseClient";
import useDebouncedValue from "../hooks/useDebouncedValue";

// Props: formId + data loaded by your useFlraFormData hook
type Props = {
  formId: string;
  formModuleId: string;
  initialData: Partial<GeneralInfo> | null;
};

const GeneralInfoForm: React.FC<Props> = ({
  formId,
  formModuleId,
  initialData,
}) => {
  // Local state - initialize with defaults for all fields
  const [values, setValues] = useState<Partial<GeneralInfo>>({
    project_name: "",
    project_address: "",
    task_location: "",
    supervisor_name: "",
    supervisor_contact: "",
    date: "",
    crew_members_count: undefined,
    task_description: "",
    start_time: "",
    end_time: "",
    ...initialData, // Override with any existing data
  });

  const [status, setStatus] = useState<"idle" | "saving" | "success" | "error">(
    "idle"
  );
  const [errorMessage, setErrorMessage] = useState<string>("");

  // Debounce the whole object by 500ms
  const debounced = useDebouncedValue(values, 500);

  // Whenever debounced changes (i.e. user paused typing), save it
  useEffect(() => {
    // If nothing actually changed from initial data, skip
    if (JSON.stringify(debounced) === JSON.stringify(initialData)) return;

    // Skip if all values are empty/default (no point saving empty form)
    const hasContent = Object.values(debounced).some(
      (value) => value !== "" && value !== null && value !== undefined
    );
    if (!hasContent) return;

    setStatus("saving");
    setErrorMessage("");

    (async () => {
      try {
        const payload = {
          formId,
          moduleKey: "general",
          data: {
            ...debounced,
            form_module_id: formModuleId,
          },
        };

        const { error } = await supabase.functions.invoke(
          "saveFormModuleData",
          {
            body: payload,
          }
        );

        if (error) {
          console.error("Save failed:", error);
          setStatus("error");
          setErrorMessage(error.message || "Save failed");
        } else {
          setStatus("success");
          // Clear success status after 2 seconds
          setTimeout(() => setStatus("idle"), 2000);
        }
      } catch (err) {
        console.error("Save error:", err);
        setStatus("error");
        setErrorMessage(err instanceof Error ? err.message : "Unknown error");
      }
    })();
  }, [debounced, formId, formModuleId, initialData]);

  // Handle input changes
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;

    let processedValue: any = value;

    // Handle number inputs
    if (type === "number") {
      processedValue = value === "" ? undefined : parseInt(value, 10);
    }

    setValues((prev) => ({ ...prev, [name]: processedValue }));
    setStatus("idle");
  };

  return (
    <div className="general-info-form">
      <h2>General Information</h2>

      {/* Status indicator */}
      <div className="save-status">
        {status === "saving" && <div className="status saving">💾 Saving…</div>}
        {status === "success" && <div className="status success">✅ Saved</div>}
        {status === "error" && (
          <div className="status error">
            ❌ Save failed{errorMessage && `: ${errorMessage}`}
          </div>
        )}
      </div>

      <form className="form-grid">
        <div className="field-group">
          <label htmlFor="project_name">
            Project Name *
            <input
              id="project_name"
              name="project_name"
              type="text"
              value={values.project_name || ""}
              onChange={handleChange}
              placeholder="Enter project name"
              required
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="project_address">
            Project Address
            <input
              id="project_address"
              name="project_address"
              type="text"
              value={values.project_address || ""}
              onChange={handleChange}
              placeholder="Enter project address"
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="task_location">
            Task Location
            <input
              id="task_location"
              name="task_location"
              type="text"
              value={values.task_location || ""}
              onChange={handleChange}
              placeholder="Specific location of work"
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="supervisor_name">
            Supervisor Name
            <input
              id="supervisor_name"
              name="supervisor_name"
              type="text"
              value={values.supervisor_name || ""}
              onChange={handleChange}
              placeholder="Enter supervisor name"
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="supervisor_contact">
            Supervisor Contact
            <input
              id="supervisor_contact"
              name="supervisor_contact"
              type="tel"
              value={values.supervisor_contact || ""}
              onChange={handleChange}
              placeholder="+1234567890"
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="date">
            Date
            <input
              id="date"
              name="date"
              type="date"
              value={values.date || ""}
              onChange={handleChange}
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="crew_members_count">
            Number of Crew Members
            <input
              id="crew_members_count"
              name="crew_members_count"
              type="number"
              min="1"
              max="100"
              value={values.crew_members_count || ""}
              onChange={handleChange}
              placeholder="Enter number of crew members"
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="start_time">
            Start Time
            <input
              id="start_time"
              name="start_time"
              type="time"
              value={values.start_time || ""}
              onChange={handleChange}
            />
          </label>
        </div>

        <div className="field-group">
          <label htmlFor="end_time">
            End Time
            <input
              id="end_time"
              name="end_time"
              type="time"
              value={values.end_time || ""}
              onChange={handleChange}
            />
          </label>
        </div>

        <div className="field-group full-width">
          <label htmlFor="task_description">
            Task Description
            <textarea
              id="task_description"
              name="task_description"
              value={values.task_description || ""}
              onChange={handleChange}
              placeholder="Describe the work to be performed"
              rows={4}
            />
          </label>
        </div>
      </form>

      <style jsx>{`
        .general-info-form {
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }

        .save-status {
          margin-bottom: 20px;
          min-height: 24px;
        }

        .status {
          padding: 8px 12px;
          border-radius: 4px;
          font-size: 14px;
          font-weight: 500;
        }

        .status.saving {
          background-color: #fef3c7;
          color: #92400e;
          border: 1px solid #fbbf24;
        }

        .status.success {
          background-color: #d1fae5;
          color: #065f46;
          border: 1px solid #10b981;
        }

        .status.error {
          background-color: #fee2e2;
          color: #991b1b;
          border: 1px solid #ef4444;
        }

        .form-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 20px;
        }

        .field-group {
          display: flex;
          flex-direction: column;
        }

        .field-group.full-width {
          grid-column: 1 / -1;
        }

        label {
          font-weight: 500;
          margin-bottom: 4px;
          color: #374151;
        }

        input,
        textarea {
          padding: 8px 12px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          font-size: 14px;
          transition: border-color 0.2s;
        }

        input:focus,
        textarea:focus {
          outline: none;
          border-color: #3b82f6;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        textarea {
          resize: vertical;
          min-height: 80px;
        }

        input[required] + label::after {
          content: " *";
          color: #ef4444;
        }
      `}</style>
    </div>
  );
};

export default GeneralInfoForm;
