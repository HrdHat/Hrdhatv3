import React, { useState, useEffect } from "react";
import { PpeChecklist } from "../types/formSchemas";
import { supabase } from "../db/supabaseClient";
import useDebouncedValue from "../hooks/useDebouncedValue";

// Props: formId + data loaded by your useFlraFormData hook
type Props = {
  formId: string;
  formModuleId: string;
  initialData: Partial<PpeChecklist> | null;
};

const PpeChecklistForm: React.FC<Props> = ({
  formId,
  formModuleId,
  initialData,
}) => {
  // Local state - initialize with defaults for all fields
  const [values, setValues] = useState<Partial<PpeChecklist>>({
    ppe_hardhat: false,
    ppe_safety_vest: false,
    ppe_safety_glasses: false,
    ppe_fall_protection: false,
    ppe_coveralls: false,
    ppe_gloves: false,
    ppe_mask: false,
    ppe_respirator: false,
    platform_ladder: false,
    platform_step_bench: false,
    platform_sawhorses: false,
    platform_baker_scaffold: false,
    platform_scaffold: false,
    platform_scissor_lift: false,
    platform_boom_lift: false,
    platform_swing_stage: false,
    platform_hydro_lift: false,
    ...initialData, // Override with any existing data
  });

  const [status, setStatus] = useState<"idle" | "saving" | "success" | "error">(
    "idle"
  );
  const [errorMessage, setErrorMessage] = useState<string>("");

  // Debounce the whole object by 500ms
  const debounced = useDebouncedValue(values, 500);

  // Whenever debounced changes (i.e. user paused typing), save it
  useEffect(() => {
    // If nothing actually changed from initial data, skip
    if (JSON.stringify(debounced) === JSON.stringify(initialData)) return;

    setStatus("saving");
    setErrorMessage("");

    (async () => {
      try {
        const payload = {
          formId,
          moduleKey: "ppeChecklist",
          data: {
            ...debounced,
            form_module_id: formModuleId,
          },
        };

        const { error } = await supabase.functions.invoke(
          "saveFormModuleData",
          {
            body: payload,
          }
        );

        if (error) {
          console.error("Save failed:", error);
          setStatus("error");
          setErrorMessage(error.message || "Save failed");
        } else {
          setStatus("success");
          // Clear success status after 2 seconds
          setTimeout(() => setStatus("idle"), 2000);
        }
      } catch (err) {
        console.error("Save error:", err);
        setStatus("error");
        setErrorMessage(err instanceof Error ? err.message : "Unknown error");
      }
    })();
  }, [debounced, formId, formModuleId, initialData]);

  // Handle checkbox changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setValues((prev) => ({ ...prev, [name]: checked }));
    setStatus("idle");
  };

  // PPE items with labels
  const ppeItems = [
    {
      key: "ppe_hardhat",
      label: "Hard Hat",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_safety_vest",
      label: "Safety Vest",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_safety_glasses",
      label: "Safety Glasses",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_fall_protection",
      label: "Fall Protection",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_coveralls",
      label: "Coveralls",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_gloves",
      label: "Gloves",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_mask",
      label: "Mask",
      category: "Personal Protective Equipment",
    },
    {
      key: "ppe_respirator",
      label: "Respirator",
      category: "Personal Protective Equipment",
    },
  ];

  const platformItems = [
    { key: "platform_ladder", label: "Ladder", category: "Platform Equipment" },
    {
      key: "platform_step_bench",
      label: "Step Bench",
      category: "Platform Equipment",
    },
    {
      key: "platform_sawhorses",
      label: "Sawhorses",
      category: "Platform Equipment",
    },
    {
      key: "platform_baker_scaffold",
      label: "Baker Scaffold",
      category: "Platform Equipment",
    },
    {
      key: "platform_scaffold",
      label: "Scaffold",
      category: "Platform Equipment",
    },
    {
      key: "platform_scissor_lift",
      label: "Scissor Lift",
      category: "Platform Equipment",
    },
    {
      key: "platform_boom_lift",
      label: "Boom Lift",
      category: "Platform Equipment",
    },
    {
      key: "platform_swing_stage",
      label: "Swing Stage",
      category: "Platform Equipment",
    },
    {
      key: "platform_hydro_lift",
      label: "Hydro Lift",
      category: "Platform Equipment",
    },
  ];

  const renderChecklistSection = (items: typeof ppeItems, title: string) => (
    <div className="checklist-section">
      <h3>{title}</h3>
      {items.map((item) => (
        <div key={item.key} className="checkbox-group">
          <label htmlFor={item.key}>
            <input
              id={item.key}
              name={item.key}
              type="checkbox"
              checked={
                (values[item.key as keyof PpeChecklist] as boolean) || false
              }
              onChange={handleChange}
            />
            <span className="checkbox-label">{item.label}</span>
          </label>
        </div>
      ))}
    </div>
  );

  return (
    <div className="ppe-checklist-form">
      <h2>PPE & Platform Equipment Checklist</h2>

      {/* Status indicator */}
      <div className="save-status">
        {status === "saving" && <div className="status saving">💾 Saving…</div>}
        {status === "success" && <div className="status success">✅ Saved</div>}
        {status === "error" && (
          <div className="status error">
            ❌ Save failed{errorMessage && `: ${errorMessage}`}
          </div>
        )}
      </div>

      <form className="checklist-form">
        {renderChecklistSection(ppeItems, "Personal Protective Equipment")}
        {renderChecklistSection(platformItems, "Platform Equipment")}
      </form>
    </div>
  );
};

export default PpeChecklistForm;
