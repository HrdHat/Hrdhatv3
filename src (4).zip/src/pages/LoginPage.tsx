import React from "react";

const LoginPage: React.FC = () => {
  return (
    <div>
      <h1>Login</h1>
      {/* Login form will go here */}
    </div>
  );
};

export default LoginPage;
