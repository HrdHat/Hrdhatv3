import React from "react";

const AboutPage: React.FC = () => {
  return (
    <div>
      <h1>About Us</h1>
      {/* About page content will go here */}
    </div>
  );
};

export default AboutPage;
