import React from "react";

const ContactPage: React.FC = () => {
  return (
    <div>
      <h1>Contact Us</h1>
      {/* Contact form will go here */}
    </div>
  );
};

export default ContactPage;
