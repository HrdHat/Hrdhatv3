// Module renderer types
export type RendererKey =
  | "GenericModuleRenderer"
  | "FlraHeaderModule"
  | "PhotoModuleRenderer"
  | "SignatureModuleRenderer"
  | "TaskHazardControlModule";

// Module with renderer interface
export interface ModuleWithRenderer {
  renderer_key?: RendererKey;
  template_modules?: {
    renderer_key?: RendererKey;
  };
  [key: string]: any;
}

// Used only if rendering fails and fallback is needed
export interface MissingRendererProps {
  moduleName: string;
  rendererKey?: string;
}
