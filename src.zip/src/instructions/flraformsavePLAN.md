Condensed and Aligned Save Logic Plan for FLRA Form
FLRA Form Save Implementation Plan
[x]1.1 Sync ModuleKey Type

Define a ModuleKey union type that includes only actual, current modules:
"header" | "general" | "preJobChecklist" | "ppeChecklist" | "taskHazards" | "photos" | "signatures"

Search for any outdated keys (e.g. "generalInfo", "ppe") and replace them project-wide.

    Update getModuleKey() and MODULE_KEY_MAP constants to reflect the new set.

[x]1.2 Align Save Params Interface

Create or update a single SaveFormModuleDataParams type:

interface SaveFormModuleDataParams {
formId: string;
moduleKey: ModuleKey;
data: any;
moduleId?: string;
}

Ensure all calls to saveFormModuleData or similar use this type.

    Remove any alternate/duplicated types like SaveFieldsParams, SaveModuleDataArgs, etc.

[x]1.3 Verify Module Data Types Match DB

For each module, check that the payload keys use snake_case and align with the corresponding Supabase table schema.

    E.g. task_location in code matches task_location in form_instance_general_info.

If your frontend uses camelCase, map/transform it before save.

    Create module-specific payload types where needed (e.g., GeneralInfoData, PpeChecklistData).

    🔍 What You Need to Look Out For

✅ 1. Do field names match the database?

    Database: form_module_id

    Frontend: formModuleId ❌

    What to do: either rename it, or convert it before saving.

✅ 2. Are the data types correct?

    Database: risk_level_before is an integer

    Frontend: make sure it's a number, not a string like "3" ❌

✅ 3. Are required fields present and not null?

    If your schema says form_module_id is required but you're sending undefined, the save will fail.

✅ 4. Are keys like form_id or form_module_id included?

    These link the module data to the right form.

    If you forget to add them to your save payload, data gets orphaned and can't be retrieved later.

✅ 5. Does each module save to the right table?

    "ppeChecklist" should go to form_instance_ppe_platform

    "signatures" should go to form_instance_signatures

    You confirm this in your tableMap in saveFormModuleData.ts

✅ 6. Zod schemas match the database

    These schemas validate data before save.

    Make sure they match the field names and types in your DB.

        Example: if DB field is task_location, your Zod shape should be task_location: z.string(), not taskLocation.

✅ 7. No old keys or unused types

    You already removed SaveFieldsParams — good.

    Now make sure there aren't any leftover fields or types like generalInfo (old name for general).

Proposal: Add Step "1.3.5"

1.3.5 Add runtime validation for all form module data and field definitions (Zod or similar)

    Create Zod schemas for each module's payload shape and for all dynamic field definitions.

    Validate all user input, form data, and dynamic field configs before saving or rendering.

    Throw or reject any data that fails validation (don't let it silently corrupt the DB).

    Use .parse() (throws) or .safeParse() (returns error info) before every .upsert() or .insert() call.

[]1.4 Normalize Field Definitions

Review all FieldDefinition objects (if used for rendering forms).

Confirm that each field's:

    type matches the expected input (text, boolean, etc.)

    label accurately describes the field

    required flag and validation match schema rules

Remove any unused or stale fields.

FOR EVERY FILE LISTED BELOW WE CHECK: ✅ What You Need to Check in These Files

For each field in the definitions above:

    Type

        Does type: "text" | "boolean" | "date" | "time" | "number" | "textarea" match the actual DB column type (from your schema2.sql or your live query)?

        For example, date: string → date, startTime: string → time without time zone, ppeHardhat: boolean → boolean.

    Label

        Does it clearly describe the field to a user? e.g., "Supervisor Contact" is acceptable; "Phone" might be unclear.

    Required

        If required: true, check if the DB column is NOT NULL. If the DB allows nulls (YES), then this may cause validation mismatch.

    Validation (Optional)

        If validation: { min, max } is defined, make sure it's:

            Reasonable

            Aligned with Supabase field constraints (if any)

            Backed by your Zod schema if used

    Remove Stale Fields

        Confirm that every field in the definitions actually appears in your:

            Zod schemas

            Module component renderers

            Database schema

So the complete final list is:
[x]src/types/formModules.ts
src/services/forms/fetchModuleFields.ts
src/modules/GenericModuleRenderer.tsx
src/hooks/useFlraFormData.ts
src/types/renderer.types.ts
src/types/formTypes.ts
src/services/forms/createFormModuleField.ts
src/services/forms/createFormModule.ts
src/modules/formmodules/FlraHeaderModule.tsx
src/services/forms/cloneFieldsFromModule.ts
src/services/forms/cloneFormStructure.ts
src/utils/formNumberGenerator.ts
src/services/forms/createForm.ts
src/types/formSchemas.ts
src/types/formSchemasStrict.ts
src/services/forms/saveFormModuleData.ts
src/services/forms/uploadImageToFormModule.ts
src/services/forms/uploadPhotoToSupabase.ts
docs/FORMSAVINGLOGIC.md
src/pages/FlraFormPage.tsx
src/types/formSchemaShapes.ts
src/modules/formmodules/SignatureModuleRenderer.tsx
src/modules/formmodules/PhotoModuleRenderer.tsx
src/modules/formmodules/SignatureModule.tsx
src/modules/formmodules/FormAssetPhotosModule.tsx
src/modules/formmodules/TaskHazardControlModule.tsx
src/modules/forms/flra/ActiveFlraDrawer.tsx
src/modules/forms/flra/FLRAFormStatePlan.md
src/components/ModuleStateIndicator.tsx
src/components/SaveQueueStatus.tsx
src/components/ModuleRenderer.tsx
src/components/shared/ImageUploaderBase.tsx
src/components/shared/SignatureCanvas.tsx
src/hooks/useSaveQueue.ts
src/hooks/useDebouncedSave.ts
src/hooks/useModuleState.ts
src/hooks/useCreateFlraForm.ts
src/constants/storage.ts
src/db/supabaseClient.ts

2. Database Mappings

Confirm table mappings. Each ModuleKey must map to the correct table in TABLES. For example:

const tableMap: Record<ModuleKey,string> = {
header: TABLES.formInstances,
general: TABLES.formInstanceGeneralInfo,
preJobChecklist: TABLES.formInstancePreJobChecklist,
ppeChecklist: TABLES.formInstancePpePlatform,
taskHazards: TABLES.formInstanceHazards,
photos: TABLES.formAssetPhotos,
signatures: TABLES.formInstanceSignatures,
};

Ensure these table names match the actual Supabase schema.

Include foreign keys. In every upsert, include the formId foreign key so rows link to the correct form instance. For array modules (taskHazards, photos, signatures), bulk-upsert each element with form_id added. For single-row modules (general, preJobChecklist, ppeChecklist, header), include form_instance_id.

    Index and constraints. Verify the database has appropriate indexes/unique constraints (e.g. on form_id) so that upserts do not create duplicate rows. If needed, specify the primary key or unique key in the upsert.

3. Save Service & API

Use a single save function. Consolidate saving logic into one service (e.g. saveFormModuleData) or edge function. This function should:

    Determine the target table via moduleKey (using the mapping above).

    Validate the payload (optionally using a runtime schema) before saving.

    Perform upsert on Supabase. For arrays, use .upsert(dataArray), for objects use .upsert(dataObject).

    Return a clear { success: boolean; error?: string } result. Catch and handle errors (network, permissions) and avoid uncaught exceptions.

Server-side validation. Before saving, check that required fields are present and of the correct type. Reject requests with missing formId, moduleKey, or invalid data. This prevents malformed data from reaching the DB.

Remove debug-only logs. The code currently logs debug info (console.debug) in development. Ensure these logs are disabled or minimal in production (or gated behind a flag). Do not log sensitive environment info.

    Environment security. Keep only the necessary Supabase keys on the client (the anon public key). Secret keys (service_role) must never be exposed in client code. If using an edge function or server API, it can use process.env.SUPABASE_KEY.

4. Client-side Integration

Debounced save hook. Implement or integrate a debounced save mechanism so that rapid changes queue up instead of firing many requests. For example, a useDebouncedSave hook that waits ~300ms after the last change before calling saveFormModuleData.

Use the save service correctly. On each module change (e.g. field blur or toggle), call the save function with { formId, moduleKey, data }. Do not send partial or unrelated data. For example:

await saveFormModuleData({ formId, moduleKey: "general", data: generalFormData });

Update form version if used. If the form uses a version counter (e.g. in form_instances.version), update the local formVersion state whenever a save succeeds. Skip this if versioning is not implemented.

    User feedback. Show clear save status in the UI. For example, display a spinner or "Saving..." when a save is in progress, and a success or error indicator when done. Use toasts or inline messages to inform the user of failures. Provide a retry option if a save fails.

5. Error Handling & Retry

Retry failed saves. Implement an exponential backoff retry for transient errors. For example, attempt up to 3 retries with delays. On final failure, mark the section as errored and prompt the user to retry.

Offline support. Detect offline status (navigator.onLine). If offline, enqueue saves in memory or local storage. Listen for the online event and flush the queue automatically.

Conflict detection (optional). If multiple users might edit the same form, handle version conflicts. For example, if saving a module fails due to a version mismatch, fetch the latest data and alert the user. (This requires a version column and extra queries; implement only if needed.)

    UI error states. Provide visual cues for unsaved/failed sections. For example, show an "Unsaved changes" banner when dirty, and highlight a module title with an error icon if its last save failed, allowing "Retry" as a button.

6. Security & Validation

Row-Level Security. Configure Supabase RLS policies so users can only modify their own form data. Ensure the supabase.from(table).upsert(...) calls respect RLS (authenticated user must own the formId).

Input sanitization. Validate or sanitize any rich text or JSON fields before saving, to prevent XSS or injection attacks.

    Remove exposed env logs. In the Supabase client, avoid logging SUPABASE_URL or SUPABASE_KEY. The code's console.log('Supabase initialized') can remain or be removed, but do not log secret values.

7. Testing

Type checking. Use TypeScript and/or Zod to ensure payloads match their interfaces. Write tests that passing incorrect payloads causes compile-time errors or runtime validation failures.

Unit tests. Test the save service in isolation: mock Supabase and verify that each moduleKey calls the correct table and payload structure. Ensure array vs object logic branches behave correctly.

Integration tests. Simulate end-to-end flows: fill a form module, trigger save, and verify the Supabase table row is created/updated. Test bulk modules (taskHazards, photos, etc.).

Error scenarios. Test network failures, 4xx/5xx responses, and offline mode to ensure retries and UI feedback work as intended.

    Performance tests. Ensure debouncing works by changing a field rapidly: only one save request should be sent after pausing. Test with large datasets (e.g. many hazard rows or photos) to ensure UI remains responsive.

Implementation Checklist

Synchronize types: Update all TypeScript types (ModuleKey, payload interfaces, save params) to match the actual schema and remove duplicates.

Field mapping: Verify field-to-column mappings; update any inconsistent naming (e.g. camelCase in code vs snake_case in DB).

Enhanced save service: Use saveFormModuleData (or API) to handle all modules. Consolidate bulk and single upserts as needed.

Debounce & queue: Implement a debounced save hook with retry and offline queuing. This ensures efficiency and reliability.

UI indicators: Add saving/error indicators in the form UI (toasts, banners, module headers) so users know the save status.

Security review: Audit Supabase usage: use only the anon key client-side, enforce RLS, and do not expose any secrets.

Lint/cleanup: Remove unused code, fix any lint errors, and ensure all environment variables have no debug logs or exposures.

    Documentation: Update code comments and README to reflect the new save logic and any setup needed (e.g. new RLS policies or edge function deployment).

This plan condenses the implementation steps, aligns them with the actual code and database schema, and highlights areas (types, mapping, error handling, security) where issues must be addressed. Following these steps will yield a clean, maintainable save flow for FLRA forms.
