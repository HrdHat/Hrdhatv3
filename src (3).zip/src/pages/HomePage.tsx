import React from "react";

const HomePage: React.FC = () => {
  return (
    <div>
      <h1>Home</h1>
      {/* Home page content will go here */}
    </div>
  );
};

export default HomePage;
