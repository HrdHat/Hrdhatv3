// index.ts

import { serve } from "https://deno.land/x/sift/mod.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js";
import { z } from "https://esm.sh/zod";

// ————————————————————————————————————————————————
// 1) Bring in your copied schemas…
import {
  generalInfoSchema,
  preJobChecklistSchema,
  ppeChecklistSchema,
  formInstanceSchema,
  taskHazardControlSchema,
  formAssetPhotoSchema,
  signatureSchema,
} from "./formSchemas.ts";

// ————————————————————————————————————————————————
// 2) Define ModuleKey (must match your moduleDataSchema keys)
type ModuleKey =
  | "header"
  | "general"
  | "preJobChecklist"
  | "ppeChecklist"
  | "taskHazards"
  | "photos"
  | "signatures";

// ————————————————————————————————————————————————
// 3) Table names from your database.ts
const TABLES = {
  formInstances: "form_instances",
  formInstanceGeneralInfo: "form_instance_general_info",
  formInstancePreJobChecklist: "form_instance_pre_job_checklist",
  formInstancePpePlatform: "form_instance_ppe_platform",
  formInstanceHazards: "form_instance_hazards",
  formAssetPhotos: "form_asset_photos",
  formInstanceSignatures: "form_instance_signatures",
} as const;

// ————————————————————————————————————————————————
// 4) Map each ModuleKey to its Zod schema
const schemaMap: Record<ModuleKey, z.ZodTypeAny> = {
  header: formInstanceSchema,
  general: generalInfoSchema,
  preJobChecklist: preJobChecklistSchema,
  ppeChecklist: ppeChecklistSchema,
  taskHazards: z.array(taskHazardControlSchema),
  photos: z.array(formAssetPhotoSchema),
  signatures: z.array(signatureSchema),
};

// ————————————————————————————————————————————————
// 5) Map each ModuleKey to its Supabase table
const tableMap: Record<ModuleKey, string> = {
  header: TABLES.formInstances,
  general: TABLES.formInstanceGeneralInfo,
  preJobChecklist: TABLES.formInstancePreJobChecklist,
  ppeChecklist: TABLES.formInstancePpePlatform,
  taskHazards: TABLES.formInstanceHazards,
  photos: TABLES.formAssetPhotos,
  signatures: TABLES.formInstanceSignatures,
};

// ————————————————————————————————————————————————
// 6) Serve the function
serve(async (req) => {
  // 6.1 Create an admin client with your service-role
  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  try {
    // 6.2 Parse request body
    const { formId, moduleKey, data, version, updated_at } =
      (await req.json()) as {
        formId: string;
        moduleKey: ModuleKey;
        data: any;
        version?: number;
        updated_at?: string;
      };

    // 6.3 Basic presence checks
    if (!formId || !moduleKey || data === undefined) {
      return new Response(
        JSON.stringify({
          success: false,
          error: "Missing formId, moduleKey, or data",
        }),
        { status: 400 }
      );
    }

    // 6.4 Zod validation
    const schema = schemaMap[moduleKey];
    if (!schema) throw new Error(`Unknown moduleKey: ${moduleKey}`);
    // Attach the form_id (and form_module_id if your schemas expect it)
    const toValidate = {
      form_id: formId,
      form_module_id: undefined,
      ...data,
    };
    const parsed = schema.parse(toValidate);

    // 6.5 Upsert into correct table
    const table = tableMap[moduleKey];
    const { error } = await supabaseAdmin
      .from(table)
      .upsert(parsed, { onConflict: ["form_id"] });

    if (error) throw error;
    return new Response(JSON.stringify({ success: true }), { status: 200 });
  } catch (e: any) {
    console.error("[saveFormModuleData] error:", e);
    return new Response(JSON.stringify({ success: false, error: e.message }), {
      status: 500,
    });
  }
});
