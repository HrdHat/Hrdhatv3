// supabase/functions/saveFormModuleData/index.ts
import { serve } from "https://deno.land/x/sift/mod.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js";
import { z } from "https://esm.sh/zod";
// Which modules need a form_module_id foreign key (ALL modules except header)
const modulesWithModuleId = new Set([
  "general",
  "preJobChecklist",
  "ppeChecklist",
  "taskHazards",
  "photos",
  "signatures",
]);
// Which modules use form_module_id for conflict resolution (single-row modules)
const modulesWithCompositeConflict = new Set([
  "general",
  "preJobChecklist",
  "ppeChecklist",
]);
const getConflictColumn = (moduleKey, isArray) => {
  if (moduleKey === "header") {
    return "id"; // Header uses primary key only
  }
  // Single-row modules use form_module_id for uniqueness
  if (modulesWithCompositeConflict.has(moduleKey) && !isArray) {
    return "form_module_id";
  }
  // Array modules use primary key (allows multiple rows per module)
  return "id";
};
const buildModulePayload = (data, moduleKey, moduleId) => {
  const addModuleId = moduleId && modulesWithModuleId.has(moduleKey);
  if (Array.isArray(data)) {
    return data.map((row) => ({
      ...row,
      ...(addModuleId && { form_module_id: moduleId }),
    }));
  }
  return {
    ...data,
    ...(addModuleId && { form_module_id: moduleId }),
  };
};
/** ──────── 2) SHAPES (from formSchemaShapes.ts) ──────── **/ const timeRegex =
  /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
const phoneRegex = /^\+?[1-9]\d{1,14}$/;
// General Info fields - ✅ NOW INCLUDES form_module_id
const generalInfoShape = {
  id: z.string().uuid().optional(),
  form_module_id: z.string().uuid(),
  project_name: z
    .string()
    .min(2, "Project name must be at least 2 characters")
    .max(100, "Project name must be less than 100 characters")
    .nullable()
    .optional(),
  form_date: z.string().datetime().optional(),
  start_time: z
    .string()
    .regex(timeRegex, "Start time must be HH:MM")
    .optional(),
  end_time: z.string().regex(timeRegex, "End time must be HH:MM").optional(),
  supervisor_name: z.string().nullable().optional(),
  supervisor_contact: z
    .string()
    .regex(phoneRegex, "Invalid phone number")
    .nullable()
    .optional(),
  work_description: z.string().nullable().optional(),
  location: z.string().nullable().optional(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
// Pre-Job Checklist fields
const preJobChecklistShape = {
  id: z.string().uuid().optional(),
  form_module_id: z.string().uuid(),
  is_fit_for_duty: z.boolean().nullable().optional(),
  reviewed_work_area_for_hazards: z.boolean().nullable().optional(),
  required_ppe_for_today: z.boolean().nullable().optional(),
  equipment_inspection_up_to_date: z.boolean().nullable().optional(),
  completed_flra_hazard_assessment: z.boolean().nullable().optional(),
  safety_signage_installed_and_checked: z.boolean().nullable().optional(),
  working_alone_today: z.boolean().nullable().optional(),
  required_permits_for_tasks: z.boolean().nullable().optional(),
  barricades_signage_barriers_installed_good: z.boolean().nullable().optional(),
  clear_access_to_emergency_exits: z.boolean().nullable().optional(),
  trained_and_competent_for_tasks: z.boolean().nullable().optional(),
  inspected_tools_and_equipment: z.boolean().nullable().optional(),
  reviewed_control_measures_needed: z.boolean().nullable().optional(),
  reviewed_emergency_procedures: z.boolean().nullable().optional(),
  all_required_permits_in_place: z.boolean().nullable().optional(),
  communicated_with_crew_about_plan: z.boolean().nullable().optional(),
  need_for_spotters_barricades_special_controls: z
    .boolean()
    .nullable()
    .optional(),
  weather_suitable_for_work: z.boolean().nullable().optional(),
  know_designated_first_aid_attendant: z.boolean().nullable().optional(),
  aware_of_site_notices_or_bulletins: z.boolean().nullable().optional(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
// PPE Checklist fields
const ppeChecklistShape = {
  id: z.string().uuid().optional(),
  form_module_id: z.string().uuid(),
  ppe_hardhat: z.boolean().nullable().optional(),
  ppe_safety_vest: z.boolean().nullable().optional(),
  ppe_safety_glasses: z.boolean().nullable().optional(),
  ppe_fall_protection: z.boolean().nullable().optional(),
  ppe_coveralls: z.boolean().nullable().optional(),
  ppe_gloves: z.boolean().nullable().optional(),
  ppe_mask: z.boolean().nullable().optional(),
  ppe_respirator: z.boolean().nullable().optional(),
  platform_ladder: z.boolean().nullable().optional(),
  platform_step_bench: z.boolean().nullable().optional(),
  platform_sawhorses: z.boolean().nullable().optional(),
  platform_baker_scaffold: z.boolean().nullable().optional(),
  platform_scaffold: z.boolean().nullable().optional(),
  platform_scissor_lift: z.boolean().nullable().optional(),
  platform_boom_lift: z.boolean().nullable().optional(),
  platform_swing_stage: z.boolean().nullable().optional(),
  platform_hydro_lift: z.boolean().nullable().optional(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
// Form Instance (header) fields - uses id only
const formInstanceShape = {
  id: z.string().uuid(),
  form_number: z.string(),
  user_id: z.string().uuid(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
// Task Hazard Control fields - uses form_module_id (not form_instance_id)
const taskHazardControlShape = {
  id: z.string().uuid().optional(),
  form_module_id: z.string().uuid(),
  task: z.string(),
  hazard: z.string(),
  risk_level_before: z.number().int().min(1).max(10).optional(),
  control: z.string(),
  risk_level_after: z.number().int().min(1).max(10).optional(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
// Photo fields - uses form_module_id (not form_instance_id)
const formAssetPhotoShape = {
  id: z.string().uuid().optional(),
  form_module_id: z.string().uuid(),
  photo_url: z.string().url(),
  photo_description: z.string().nullable().optional(),
  uploaded_at: z.string().datetime(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
// Signature fields - uses form_module_id (not form_instance_id)
const signatureShape = {
  id: z.string().uuid().optional(),
  form_module_id: z.string().uuid(),
  worker_name: z.string(),
  signature_url: z.string().url(),
  signed_at: z.string().datetime(),
  signature_hash: z.string().optional(),
  role: z.string().optional(),
  metadata: z.any().optional(),
  signed_by: z.string().uuid().optional(),
  is_deleted: z.boolean().optional(),
  deleted_at: z.string().datetime().optional(),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
};
/** ──────── 3) ZOD SCHEMAS ──────── **/ const generalInfoSchema =
  z.object(generalInfoShape);
const preJobChecklistSchema = z.object(preJobChecklistShape);
const ppeChecklistSchema = z.object(ppeChecklistShape);
const formInstanceSchema = z.object(formInstanceShape);
const taskHazardControlSchema = z.object(taskHazardControlShape);
const formAssetPhotoSchema = z.object(formAssetPhotoShape);
const signatureSchema = z.object(signatureShape);
/** ──────── 4) TABLES & tableMap ──────── **/ const TABLES = {
  formInstances: "form_instances",
  formInstanceGeneralInfo: "form_instance_general_info",
  formInstancePreJobChecklist: "form_instance_pre_job_checklist",
  formInstancePpePlatform: "form_instance_ppe_platform",
  formInstanceHazards: "form_instance_hazards",
  formAssetPhotos: "form_asset_photos",
  formInstanceSignatures: "form_instance_signatures",
};
const tableMap = {
  header: TABLES.formInstances,
  general: TABLES.formInstanceGeneralInfo,
  preJobChecklist: TABLES.formInstancePreJobChecklist,
  ppeChecklist: TABLES.formInstancePpePlatform,
  taskHazards: TABLES.formInstanceHazards,
  photos: TABLES.formAssetPhotos,
  signatures: TABLES.formInstanceSignatures,
};
/** ──────── 5) schemaMap ──────── **/ const schemaMap = {
  header: formInstanceSchema,
  general: generalInfoSchema,
  preJobChecklist: preJobChecklistSchema,
  ppeChecklist: ppeChecklistSchema,
  taskHazards: z.array(taskHazardControlSchema),
  photos: z.array(formAssetPhotoSchema),
  signatures: z.array(signatureSchema),
};
/** ──────── 6) Edge Function Handler ──────── **/ serve(async (req) => {
  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL"),
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")
  );
  try {
    const { moduleKey, data, moduleId } = await req.json();
    if (!moduleKey || data === undefined || !moduleId) {
      return new Response(
        JSON.stringify({
          success: false,
          error: "Missing moduleKey/data/moduleId",
        }),
        {
          status: 400,
        }
      );
    }
    // Validate with Zod
    const schema = schemaMap[moduleKey];
    if (!schema) {
      return new Response(
        JSON.stringify({
          success: false,
          error: `Unknown moduleKey: ${moduleKey}`,
        }),
        {
          status: 400,
        }
      );
    }
    // Build payload with proper foreign keys using centralized config
    const payload = buildModulePayload(data, moduleKey, moduleId);
    // Generate IDs and timestamps if needed
    if (Array.isArray(payload)) {
      payload.forEach((row) => {
        if (!row.id) row.id = crypto.randomUUID();
        if (!row.created_at) row.created_at = new Date().toISOString();
      });
    } else {
      if (!payload.id) payload.id = crypto.randomUUID();
      if (!payload.created_at) payload.created_at = new Date().toISOString();
    }
    // Validate the final payload
    const validatedPayload = schema.parse(payload);
    // Get conflict resolution strategy using centralized config
    const conflictColumn = getConflictColumn(
      moduleKey,
      Array.isArray(validatedPayload)
    );
    // Upsert into correct table
    const table = tableMap[moduleKey];
    const { error } = await supabaseAdmin.from(table).upsert(validatedPayload, {
      onConflict: conflictColumn,
    });
    if (error) throw error;
    return new Response(
      JSON.stringify({
        success: true,
      }),
      {
        status: 200,
      }
    );
  } catch (e) {
    console.error("[saveFormModuleData] error:", e);
    return new Response(
      JSON.stringify({
        success: false,
        error: e.message,
      }),
      {
        status: 500,
      }
    );
  }
});
